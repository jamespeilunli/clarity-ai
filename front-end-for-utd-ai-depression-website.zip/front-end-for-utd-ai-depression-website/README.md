# Front-end for UTD AI depression website

A Pen created on CodePen.io. Original URL: [https://codepen.io/ab1324/pen/zYVryPO](https://codepen.io/ab1324/pen/zYVryPO).

https://github.com/jamespeilunli/utd-summer-ai